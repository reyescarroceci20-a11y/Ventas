/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mystore.controlador;

import com.mystore.dao.ClienteDAO;
import com.mystore.modelo.Cliente;
import com.mystore.vista.DlgCliente;
import com.mystore.vista.PnlCliente;
import java.awt.Frame;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Cecilia
 */
public class ClienteController {

    private final PnlCliente vista;
    private final ClienteDAO dao;
    private final DefaultTableModel modeloTabla;

    public ClienteController(PnlCliente vista) {
        this.vista = vista;
        this.dao = new ClienteDAO();
        this.modeloTabla = (DefaultTableModel) vista.getTblCliente().getModel();

        cargarTabla();

        vista.getButtonBuscar().addActionListener(e -> buscar());
        vista.getCajaDeTextoBuscar().addActionListener(e -> buscar());
        vista.getButtonNuevo().addActionListener(e -> registrarCliente());
        vista.getButtonEditar().addActionListener(e -> editarCliente());
        vista.getButtonEliminar().addActionListener(e -> eliminarCliente());
        vista.getBtnDesmarcar().addActionListener(e -> vista.getTblCliente().clearSelection());
    }

    public void cargarTabla() {
        modeloTabla.setRowCount(0);
        List<Cliente> lista = dao.listarClientes();

        for (Cliente c : lista) {
            Object[] fila = {
                c.getIdCliente(),
                c.getNombreCompleto(),
                c.getTelefono(),
                c.getDireccion()
            };
            modeloTabla.addRow(fila);
        }
    }

    public void buscar() {
        String txt = vista.getCajaDeTextoBuscar().getText().trim();
        modeloTabla.setRowCount(0);

        List<Cliente> lista = txt.isEmpty() ? dao.listarClientes() : dao.buscarPorNombre(txt);

        for (Cliente c : lista) {
            Object[] fila = {
                c.getIdCliente(),
                c.getNombreCompleto(),
                c.getTelefono(),
                c.getDireccion()
            };
            modeloTabla.addRow(fila);
        }
    }

    public void registrarCliente() {
        DlgCliente dlg = new DlgCliente((Frame) null, true);
        dlg.setVisible(true);

        if (dlg.guardado) {
            Cliente c = dlg.getCliente();
            if (dao.registrar(c)) {
                JOptionPane.showMessageDialog(vista, "Cliente registrado correctamente.");
                cargarTabla();
            } else {
                JOptionPane.showMessageDialog(vista, "Error al registrar cliente.");
            }
        }
    }

    public void editarCliente() {
        int fila = vista.getTblCliente().getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(vista, "Selecciona un cliente para editar.");
            return;
        }

        int idCliente = Integer.parseInt(vista.getTblCliente().getValueAt(fila, 0).toString());

        Cliente clienteBD = dao.buscarPorId(idCliente); 

        if (clienteBD == null) {
            JOptionPane.showMessageDialog(vista, "No se pudo cargar el cliente seleccionado.");
            return;
        }

        DlgCliente dlg = new DlgCliente((Frame) null, true, clienteBD);
        dlg.setLocationRelativeTo(null);
        dlg.setVisible(true);


        cargarTabla();
    }

    public void eliminarCliente() {
        int fila = vista.getTblCliente().getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(vista, "Selecciona un cliente para eliminar.");
            return;
        }

        int id = Integer.parseInt(vista.getTblCliente().getValueAt(fila, 0).toString());
        String nombre = vista.getTblCliente().getValueAt(fila, 1).toString();

        int confirm = JOptionPane.showConfirmDialog(vista, "¿Eliminar al cliente: " + nombre + "?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (dao.eliminar(id)) {
                JOptionPane.showMessageDialog(vista, "Cliente eliminado correctamente.");
                cargarTabla();
            } else {
                JOptionPane.showMessageDialog(vista, "Error al eliminar cliente.");
            }
        }
    }

}
