/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mystore.dao;

import com.mystore.modelo.Cliente;
import com.mystore.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ericr
 */
public class ClienteDAO {

    public List<Cliente> listarClientes() {
        List<Cliente> lista = new ArrayList<>();
        String sql = "SELECT * FROM Cliente ORDER BY id_cliente ASC";

        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Cliente c = new Cliente();
                c.setIdCliente(rs.getInt("id_cliente"));
                c.setNombreCompleto(rs.getString("nombre_completo"));
                c.setTelefono(rs.getString("telefono"));
                c.setDireccion(rs.getString("direccion"));
                lista.add(c);
            }
        } catch (Exception e) {
            System.err.println("Error al listar Clientes: " + e.getMessage());
        }
        return lista;
    }

    public boolean registrar(Cliente c) {
        if (!sonDatosValidos(c)) {
            return false;
        }

        String sql = "INSERT INTO Cliente (nombre_completo, telefono, direccion) VALUES (?, ?, ?)";
        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getNombreCompleto().trim());
            ps.setString(2, c.getTelefono().trim());
            ps.setString(3, c.getDireccion().trim());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            System.err.println("Error en BD al registrar: " + e.getMessage());
            return false;
        }
    }

    public boolean modificar(Cliente c) {
        String sql = "UPDATE Cliente SET nombre_completo=?, telefono=?, direccion=? WHERE id_cliente=?";
        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getNombreCompleto());
            ps.setString(2, c.getTelefono());
            ps.setString(3, c.getDireccion());
            ps.setInt(4, c.getIdCliente());
            int filas = ps.executeUpdate();
            System.out.println("Filas actualizadas: " + filas + " | id_cliente: " + c.getIdCliente());
            return filas > 0;
        } catch (Exception e) {
            System.err.println("Error al modificar cliente: " + e.getMessage()); // ← AGREGA ESTO
            return false;
        }
    }

    public boolean eliminar(int idCliente) {
        String sql = "DELETE FROM Cliente WHERE id_cliente=?";
        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idCliente);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    // --- NUEVOS MÉTODOS DE BÚSQUEDA ---
    // 1. Método para buscar por ID (Devuelve un solo cliente)
    public Cliente buscarPorId(int id) {
        Cliente c = null;
        String sql = "SELECT * FROM Cliente WHERE id_cliente = ?";

        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    c = new Cliente();
                    c.setIdCliente(rs.getInt("id_cliente"));
                    c.setNombreCompleto(rs.getString("nombre_completo"));
                    c.setTelefono(rs.getString("telefono"));
                    c.setDireccion(rs.getString("direccion"));
                }
            }
        } catch (Exception e) {
            System.err.println("Error al buscar Cliente por ID: " + e.getMessage());
        }
        return c;
    }

    // 2. Método para buscar por Nombre (Devuelve una lista por si hay coincidencias múltiples)
    public List<Cliente> buscarPorNombre(String texto) {
        List<Cliente> lista = new ArrayList<>();
        String sql = "SELECT * FROM Cliente WHERE UPPER(nombre_completo) LIKE UPPER(?)";

        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + texto + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Cliente c = new Cliente();
                    c.setIdCliente(rs.getInt("id_cliente"));
                    c.setNombreCompleto(rs.getString("nombre_completo"));
                    c.setTelefono(rs.getString("telefono"));
                    c.setDireccion(rs.getString("direccion"));
                    lista.add(c);
                }
            }
        } catch (Exception e) {
            System.err.println("Error al buscar Cliente por nombre: " + e.getMessage());
        }
        return lista;
    }

    private boolean sonDatosValidos(Cliente c) {
        if (c.getNombreCompleto() == null || c.getTelefono() == null || c.getDireccion() == null) {
            System.err.println("Error: Ningún campo puede ser nulo.");
            return false;
        }
        String regexNombre = "^[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]{3,100}$";
        if (!c.getNombreCompleto().matches(regexNombre)) {
            System.err.println("Error: El nombre contiene caracteres inválidos o es muy corto.");
            return false;
        }
        String regexTelefono = "^\\d{10}$";
        if (!c.getTelefono().matches(regexTelefono)) {
            System.err.println("Error: El teléfono debe contener exactamente 10 números.");
            return false;
        }
        if (c.getDireccion().trim().isEmpty()) {
            System.err.println("Error: La dirección no puede estar vacía.");
            return false;
        }
        return true;
    }
}
