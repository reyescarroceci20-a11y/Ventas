/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mystore.vista;

import javax.swing.JFrame;

/**
 *
 * @author ericr
 */
public class PuntoDeVenta {

    public static void main(String[] args) {
        // Arrancar la aplicación directamente en el Menú Principal
        java.awt.EventQueue.invokeLater(() -> {

            // Creamos la ventana principal 
            JFrame ventanaPrincipal = new JFrame("Sistema de Punto de Venta Distribuido");
            ventanaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // Le agregamos tu menú principal (PnlEscritorio)
            ventanaPrincipal.getContentPane().add(new PnlEscritorio());

            // Ajustamos el tamaño y la centramos en la pantalla
            ventanaPrincipal.pack();
            ventanaPrincipal.setLocationRelativeTo(null);

            // 1. ACTIVAMOS EL MODO RESPONSIVO (Permite cambiar el tamaño)
            ventanaPrincipal.setResizable(true);

            // La hacemos visible
            ventanaPrincipal.setVisible(true);

        });
    }
}
