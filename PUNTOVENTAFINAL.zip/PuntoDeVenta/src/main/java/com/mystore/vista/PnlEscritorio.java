/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.mystore.vista;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ericr
 */
public class PnlEscritorio extends javax.swing.JPanel {

    //Inicializa el panel de escritorio
    public PnlEscritorio() {
        initComponents();
        actualizarVentasHoy();

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.JButton[] menuBotones = {buttonVentas, buttonProductos, buttonClientes, btnUsuarios, btnFiltroHoy, btnFiltroMes, btnFiltroAnio, btnFiltroSemana};

        for (javax.swing.JButton btn : menuBotones) {

            btn.setBackground(new java.awt.Color(33, 45, 59));
            btn.setForeground(new java.awt.Color(255, 255, 255));

            btn.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14));
            btn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
            btn.setIconTextGap(15);
            btn.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 20, 10, 10)); // Margen interno (Padding)
            btn.setContentAreaFilled(false);
            btn.setFocusPainted(false);
            btn.setOpaque(true);

            btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

            btn.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    btn.setBackground(new java.awt.Color(45, 60, 80));
                }

                public void mouseExited(java.awt.event.MouseEvent evt) {
                    btn.setBackground(new java.awt.Color(33, 45, 59));
                }
            });
        }

        try {
            buttonVentas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventas.png")));
            buttonProductos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/productos.png")));
            buttonClientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/clientes.png")));
            btnUsuarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/usuarios.png")));

        } catch (Exception e) {
            System.out.println("¡ALERTA! No encuentro una imagen: " + e.getMessage());
        }

        cargarHistorialVentas();
    }

    private void cambiarPantalla(javax.swing.JPanel p) {
        jPanel7.removeAll();
        jPanel7.setLayout(new java.awt.BorderLayout());
        jPanel7.add(p, java.awt.BorderLayout.CENTER);
        jPanel7.revalidate();
        jPanel7.repaint();
    }

    //Actualiza las ventas de hoy
    private void actualizarVentasHoy() {
        // SQL para sumar todo lo vendido hoy
        String sql = "SELECT NVL(SUM(d.cantidad * d.precio_unitario), 0) FROM Venta v JOIN Detalle_Venta d ON v.id_venta = d.id_venta WHERE TRUNC(v.fecha_venta) = TRUNC(SYSDATE)";

        try (java.sql.Connection con = com.mystore.util.Conexion.getConnection(); java.sql.PreparedStatement ps = con.prepareStatement(sql); java.sql.ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                double total = rs.getDouble(1);
                jLabel3.setText("$ " + String.format("%.2f", total));
            }
        } catch (Exception e) {
            System.err.println("Error al calcular ventas de hoy: " + e);
        }
    }

    // Método que aplica la teoría de la vista optimizada y el NATURAL JOIN
    private void actualizarVentasOptimizadas(String condicionFecha, String titulo) {

        // ¡Aquí está la magia de tu clase aplicada a la vida real!
        // Cruzamos la tabla local (Detalle_Venta) con la vista remota (v_productos_optimizada)
        String sql = "SELECT NVL(SUM(cantidad * precio_unitario), 0) "
                + "FROM Venta v "
                + "JOIN Detalle_Venta ON v.id_venta = Detalle_Venta.id_venta "
                + "NATURAL JOIN v_productos_optimizada "
                + "WHERE " + condicionFecha;

        try (java.sql.Connection con = com.mystore.util.Conexion.getConnection(); java.sql.PreparedStatement ps = con.prepareStatement(sql); java.sql.ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                double total = rs.getDouble(1);
                jLabel3.setText("$ " + String.format("%.2f", total));
                jLabel2.setText(titulo); // Esto cambiará el título de arriba
            }
        } catch (Exception e) {
            System.err.println("Error en consulta optimizada distribuida: " + e);
        }
    }

    public void cargarHistorialVentas() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Folio");
        modelo.addColumn("Fecha/Hora");
        modelo.addColumn("Producto");
        modelo.addColumn("Cant.");
        modelo.addColumn("Subtotal");

        tblHistorial.setModel(modelo);

        String sql = "SELECT Folio, Hora_Exacta, Producto, Cant, Subtotal FROM v_historial_detallado ORDER BY Folio DESC";

        try (java.sql.Connection con = com.mystore.util.Conexion.getConnection(); java.sql.PreparedStatement ps = con.prepareStatement(sql); java.sql.ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Object[] fila = {
                    rs.getInt("Folio"),
                    rs.getString("Hora_Exacta"),
                    rs.getString("Producto"),
                    rs.getInt("Cant"),
                    "$ " + rs.getDouble("Subtotal")
                };
                modelo.addRow(fila);
            }
        } catch (Exception e) {
            System.err.println("Error al cargar historial: " + e);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        buttonVentas = new javax.swing.JButton();
        buttonProductos = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnFiltroHoy = new javax.swing.JButton();
        btnFiltroSemana = new javax.swing.JButton();
        btnFiltroMes = new javax.swing.JButton();
        btnFiltroAnio = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblHistorial = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnResumen = new javax.swing.JButton();
        btnHistorial = new javax.swing.JButton();
        btnUsuarios = new javax.swing.JButton();
        buttonClientes = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(1130, 650));

        jPanel1.setPreferredSize(new java.awt.Dimension(1130, 650));

        jPanel2.setBackground(new java.awt.Color(33, 45, 59));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.setPreferredSize(new java.awt.Dimension(1130, 650));

        jPanel3.setBackground(new java.awt.Color(33, 45, 59));
        jPanel3.setForeground(new java.awt.Color(245, 242, 245));
        jPanel3.setMinimumSize(new java.awt.Dimension(1050, 693));
        jPanel3.setPreferredSize(new java.awt.Dimension(220, 0));
        jPanel3.setRequestFocusEnabled(false);

        buttonVentas.setBackground(new java.awt.Color(33, 45, 59));
        buttonVentas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        buttonVentas.setForeground(new java.awt.Color(255, 255, 255));
        buttonVentas.setText("Ventas");
        buttonVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonVentasActionPerformed(evt);
            }
        });

        buttonProductos.setBackground(new java.awt.Color(33, 45, 59));
        buttonProductos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        buttonProductos.setForeground(new java.awt.Color(255, 255, 255));
        buttonProductos.setText("Productos");
        buttonProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonProductosActionPerformed(evt);
            }
        });

        jPanel7.setBackground(new java.awt.Color(245, 246, 250));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        jLabel2.setBackground(new java.awt.Color(100, 100, 100));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel2.setText("Ventas de Hoy");

        jLabel3.setBackground(new java.awt.Color(0, 51, 153));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setText("$ 0.00");

        btnFiltroHoy.setBackground(new java.awt.Color(33, 45, 59));
        btnFiltroHoy.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnFiltroHoy.setForeground(new java.awt.Color(255, 255, 255));
        btnFiltroHoy.setText("Hoy");
        btnFiltroHoy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFiltroHoyActionPerformed(evt);
            }
        });

        btnFiltroSemana.setBackground(new java.awt.Color(33, 45, 59));
        btnFiltroSemana.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnFiltroSemana.setForeground(new java.awt.Color(255, 255, 255));
        btnFiltroSemana.setText("Última Semana");
        btnFiltroSemana.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFiltroSemanaActionPerformed(evt);
            }
        });

        btnFiltroMes.setBackground(new java.awt.Color(33, 45, 59));
        btnFiltroMes.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnFiltroMes.setForeground(new java.awt.Color(255, 255, 255));
        btnFiltroMes.setText("Último Mes");
        btnFiltroMes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFiltroMesActionPerformed(evt);
            }
        });

        btnFiltroAnio.setBackground(new java.awt.Color(33, 45, 59));
        btnFiltroAnio.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnFiltroAnio.setForeground(new java.awt.Color(255, 255, 255));
        btnFiltroAnio.setText("Este Año");
        btnFiltroAnio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFiltroAnioActionPerformed(evt);
            }
        });

        tblHistorial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblHistorial);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(217, 217, 217)
                                .addComponent(jLabel3))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 639, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 46, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(btnFiltroHoy)
                                .addGap(226, 226, 226)
                                .addComponent(btnFiltroAnio)
                                .addGap(73, 73, 73)
                                .addComponent(btnFiltroSemana))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(136, 136, 136)
                                .addComponent(btnFiltroMes)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(28, 28, 28)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFiltroHoy)
                    .addComponent(btnFiltroMes)
                    .addComponent(btnFiltroAnio)
                    .addComponent(btnFiltroSemana))
                .addGap(100, 100, 100)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(136, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1238, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 174, Short.MAX_VALUE)
        );

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Noto Sans SC", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText(" Punto de Venta");

        btnResumen.setBackground(new java.awt.Color(99, 186, 99));
        btnResumen.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnResumen.setText("Resumen");
        btnResumen.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        btnResumen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResumenActionPerformed(evt);
            }
        });

        btnHistorial.setBackground(new java.awt.Color(33, 45, 59));
        btnHistorial.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnHistorial.setForeground(new java.awt.Color(255, 255, 255));
        btnHistorial.setText("Historial");
        btnHistorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHistorialActionPerformed(evt);
            }
        });

        btnUsuarios.setBackground(new java.awt.Color(33, 45, 59));
        btnUsuarios.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnUsuarios.setForeground(new java.awt.Color(255, 255, 255));
        btnUsuarios.setText("Usuarios");
        btnUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUsuariosActionPerformed(evt);
            }
        });

        buttonClientes.setBackground(new java.awt.Color(33, 45, 59));
        buttonClientes.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        buttonClientes.setForeground(new java.awt.Color(255, 255, 255));
        buttonClientes.setText("Clientes");
        buttonClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonClientesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(buttonClientes, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnUsuarios, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(buttonProductos, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(btnHistorial, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(buttonVentas, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(12, 12, 12))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(btnResumen, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, Short.MAX_VALUE)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(232, 232, 232)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(buttonVentas, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnHistorial, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addComponent(buttonProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(7, 7, 7)
                .addComponent(btnUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(7, 7, 7)
                .addComponent(buttonClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(134, 134, 134)
                .addComponent(btnResumen, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(114, 114, 114))
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 946, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 650, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 946, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 946, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void buttonProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonProductosActionPerformed
        // TODO add your handling code here:
        cambiarPantalla(new com.mystore.vista.PnlProductos());
    }//GEN-LAST:event_buttonProductosActionPerformed

    private void buttonVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonVentasActionPerformed
        // TODO add your handling code here:
        cambiarPantalla(new com.mystore.vista.PnlVentas());
    }//GEN-LAST:event_buttonVentasActionPerformed

    private void btnFiltroHoyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFiltroHoyActionPerformed
        // TODO add your handling code here:
        actualizarVentasOptimizadas("TRUNC(fecha_venta) = TRUNC(SYSDATE)", "Ventas de Hoy");
    }//GEN-LAST:event_btnFiltroHoyActionPerformed

    private void btnFiltroSemanaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFiltroSemanaActionPerformed
        // TODO add your handling code here:
        actualizarVentasOptimizadas("fecha_venta >= SYSDATE - 7", "Última Semana");
    }//GEN-LAST:event_btnFiltroSemanaActionPerformed

    private void btnFiltroMesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFiltroMesActionPerformed
        // TODO add your handling code here:
        actualizarVentasOptimizadas("fecha_venta >= ADD_MONTHS(SYSDATE, -1)", "Último Mes");
    }//GEN-LAST:event_btnFiltroMesActionPerformed

    private void btnFiltroAnioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFiltroAnioActionPerformed
        // TODO add your handling code here:
        actualizarVentasOptimizadas("EXTRACT(YEAR FROM fecha_venta) = EXTRACT(YEAR FROM SYSDATE)", "Ventas del Año");
    }//GEN-LAST:event_btnFiltroAnioActionPerformed

    private void btnResumenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResumenActionPerformed
        // TODO add your handling code here:
        // 1. Volvemos a colocar el panel del dashboard (jPanel5) en el centro de la pantalla
        cambiarPantalla(jPanel5);

        // 2. Ejecutamos la consulta de hoy para que el dinero se actualice 
        // automáticamente por si hiciste una venta en la otra pantalla
        actualizarVentasHoy();

        // 3. Regresamos el título a su estado original por estética
        jLabel2.setText("Ventas de Hoy");
    }//GEN-LAST:event_btnResumenActionPerformed

    private void btnHistorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHistorialActionPerformed
        cambiarPantalla(new com.mystore.vista.HistorialVentas());
    }//GEN-LAST:event_btnHistorialActionPerformed

    private void btnUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUsuariosActionPerformed
        cambiarPantalla(new com.mystore.vista.PnlUsuarios());
    }//GEN-LAST:event_btnUsuariosActionPerformed

    private void buttonClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonClientesActionPerformed
        cambiarPantalla(new com.mystore.vista.PnlCliente());
    }//GEN-LAST:event_buttonClientesActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFiltroAnio;
    private javax.swing.JButton btnFiltroHoy;
    private javax.swing.JButton btnFiltroMes;
    private javax.swing.JButton btnFiltroSemana;
    private javax.swing.JButton btnHistorial;
    private javax.swing.JButton btnResumen;
    private javax.swing.JButton btnUsuarios;
    private javax.swing.JButton buttonClientes;
    private javax.swing.JButton buttonProductos;
    private javax.swing.JButton buttonVentas;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblHistorial;
    // End of variables declaration//GEN-END:variables

}
