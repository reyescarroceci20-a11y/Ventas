/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mystore.dao;

import com.mystore.modelo.Venta;
import com.mystore.modelo.VentaDetalle;
import com.mystore.util.Conexion;
import java.sql.*;
import java.util.List;

/**
 *
 * @author Cecilia
 */
public class VentaDAO {


    /*
     * Registra la venta principal en la base de datos
     * y devuelve el ID generado automáticamente.
     */
    public int registrarVenta(Venta v) {

        String sql = "INSERT INTO Venta "
                + "(total, metodo_pago, estado) "
                + "VALUES (?, ?, ?)";

        try (
                Connection con = Conexion.getConnection();
                PreparedStatement ps = con.prepareStatement(
                        sql,
                        new String[]{"ID_VENTA"}
                )) {

            ps.setDouble(1, v.getTotal());
            ps.setString(2, v.getMetodoPago());
            ps.setString(3, v.getEstado());

            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return -1;
    }

    /*
     * Registra todos los productos pertenecientes
     * a una venta dentro de la tabla Detalle_Venta.
     */
    public boolean registrarDetalle(List<VentaDetalle> detalles) {

        String sql = "INSERT INTO Detalle_Venta "
                + "(id_venta, id_producto, cantidad, precio_unitario) "
                + "VALUES (?, ?, ?, ?)";

        try (
                Connection con = Conexion.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            for (VentaDetalle d : detalles) {

                ps.setInt(1, d.getIdVenta());
                ps.setInt(2, d.getIdProducto());
                ps.setInt(3, d.getCantidad());
                ps.setDouble(4, d.getPrecioUnitario());

                ps.addBatch();
            }

            ps.executeBatch();

            return true;

        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }

    /*
     * Obtiene todas las ventas registradas
     * ordenadas desde la más reciente.
     */
    public ResultSet listarVentas() {

        String sql = "SELECT * FROM Venta ORDER BY id_venta DESC";

        try {

            Connection con = Conexion.getConnection();

            PreparedStatement ps = con.prepareStatement(sql);

            return ps.executeQuery();

        } catch (Exception e) {

            e.printStackTrace();
            return null;
        }
    }

    /*
     * Actualiza el estado de una venta.
     * Ejemplo:
     * - Completada
     * - Cancelada
     * - Pendiente
     */
    public boolean actualizarEstado(int idVenta, String estado) {

        String sql = "UPDATE Venta "
                + "SET estado = ? "
                + "WHERE id_venta = ?";

        try (
                Connection con = Conexion.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, estado);
            ps.setInt(2, idVenta);

            ps.executeUpdate();

            return true;

        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }

    /*
     * Elimina una venta y también todos los
     * productos relacionados en Detalle_Venta.
     */
    public boolean eliminarVenta(int idVenta) {

        String sqlDetalle = "DELETE FROM Detalle_Venta "
                + "WHERE id_venta = ?";

        String sqlVenta = "DELETE FROM Venta "
                + "WHERE id_venta = ?";

        try (Connection con = Conexion.getConnection()) {

            PreparedStatement psDetalle
                    = con.prepareStatement(sqlDetalle);

            psDetalle.setInt(1, idVenta);

            psDetalle.executeUpdate();

            PreparedStatement psVenta
                    = con.prepareStatement(sqlVenta);

            psVenta.setInt(1, idVenta);

            psVenta.executeUpdate();

            return true;

        } catch (Exception e) {

            e.printStackTrace();
            return false;
        }
    }
}
