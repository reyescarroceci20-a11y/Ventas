/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mystore.dao;

import com.mystore.modelo.Usuario;
import com.mystore.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author ericr
 */
public class UsuarioDAO {

    // 1. Método para buscar por ID exacto
    public Usuario buscarPorId(int id) {
        Usuario u = null;
        String sql = "SELECT id_usuario, nombre, nombreUsuario, contrasena FROM Usuario WHERE id_usuario = ?";

        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    u = new Usuario();
                    u.setId_usuario(rs.getInt("id_usuario"));
                    u.setNombre(rs.getString("nombre"));
                    u.setNombreUsuario(rs.getString("nombreUsuario"));
                    u.setContrasena(rs.getString("contrasena"));
                }
            }
        } catch (Exception e) {
            System.err.println("Error al buscar Usuario por ID: " + e);
        }
        return u;
    }

    // 2. Método para buscar por Nombre o Username
    public Usuario buscarPorNombre(String nombreBusqueda) {
        Usuario u = null;
        String sql = "SELECT id_usuario, nombre, nombreUsuario, contrasena FROM Usuario WHERE LOWER(nombre) LIKE LOWER(?) OR LOWER(nombreUsuario) LIKE LOWER(?)";

        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            // Los % ayudan a encontrar el texto aunque esté incompleto
            ps.setString(1, "%" + nombreBusqueda + "%");
            ps.setString(2, "%" + nombreBusqueda + "%");

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    u = new Usuario();
                    u.setId_usuario(rs.getInt("id_usuario"));
                    u.setNombre(rs.getString("nombre"));
                    u.setNombreUsuario(rs.getString("nombreUsuario"));
                    u.setContrasena(rs.getString("contrasena"));
                }
            }
        } catch (Exception e) {
            System.err.println("Error al buscar Usuario por nombre: " + e);
        }
        return u;
    }
}
