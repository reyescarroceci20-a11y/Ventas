/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mystore.dao;

import com.mystore.modelo.Producto;
import com.mystore.util.Conexion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ericr
 */
public class ProductoDAO {

    public List<Producto> listar() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT id_producto, nombre, precio, stock FROM Producto ORDER BY id_producto ASC";

        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Producto p = new Producto();
                p.setId_producto(rs.getInt("id_producto"));
                p.setNombre(rs.getString("nombre"));
                p.setPrecio(rs.getDouble("precio"));
                p.setStock(rs.getInt("stock"));
                lista.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean registrar(Producto p) {
        String sql = "INSERT INTO Producto (nombre, precio, stock) VALUES (?, ?, ?)";
        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getNombre());
            ps.setDouble(2, p.getPrecio());
            ps.setInt(3, p.getStock());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean modificar(Producto p) {
        String sql = "UPDATE Producto SET nombre=?, precio=?, stock=? WHERE id_producto=?";
        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getNombre());
            ps.setDouble(2, p.getPrecio());
            ps.setInt(3, p.getStock());
            ps.setInt(4, p.getId_producto());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM Producto WHERE id_producto=?";
        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    public Producto buscarPorId(int id) {
        com.mystore.modelo.Producto p = null;
        String sql = "SELECT id_producto, nombre, precio, stock FROM Producto WHERE id_producto = ?";

        try (java.sql.Connection con = com.mystore.util.Conexion.getConnection(); java.sql.PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (java.sql.ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    p = new com.mystore.modelo.Producto();
                    p.setId_producto(rs.getInt("id_producto"));
                    p.setNombre(rs.getString("nombre"));
                    p.setPrecio(rs.getDouble("precio"));
                    p.setStock(rs.getInt("stock"));
                }
            }
        } catch (Exception e) {
            System.err.println("Error al buscar Producto por ID: " + e.getMessage());
        }
        return p;
    }

    public List<Producto> buscarPorNombre(String nombreBusqueda) {
        List<Producto> lista = new ArrayList<>();
        // El LIKE y los % sirven para buscar coincidencias parciales, ignorando mayúsculas/minúsculas
        String sql = "SELECT id_producto, nombre, precio, stock FROM Producto WHERE LOWER(nombre) LIKE LOWER(?)";

        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, "%" + nombreBusqueda + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Producto p = new Producto();
                    p.setId_producto(rs.getInt("id_producto"));
                    p.setNombre(rs.getString("nombre"));
                    p.setPrecio(rs.getDouble("precio"));
                    p.setStock(rs.getInt("stock"));
                    lista.add(p);
                }
            }
        } catch (Exception e) {
            System.err.println("Error al buscar Producto por nombre: " + e.getMessage());
        }
        return lista;
    }
}
