/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mystore.controlador;

import com.mystore.dao.ProductoDAO;
import com.mystore.modelo.Producto;
import com.mystore.vista.DlgProducto;
import com.mystore.vista.PnlProductos;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.JOptionPane;

/**
 *
 * @author ericr
 */
public class ProductoController {

    private PnlProductos vista;
    private ProductoDAO dao;

    public ProductoController(PnlProductos vista) {
        this.vista = vista;
        this.dao = new ProductoDAO();
        cargarTabla();
    }

    public void cargarTabla() {
        List<Producto> lista = dao.listar();
        vista.actualizarTabla(lista);
    }

    public void buscar(String texto) {
        if (texto.isEmpty()) {
            cargarTabla();
            return;
        }

        List<Producto> filtrados = dao.listar().stream()
                .filter(p -> p.getNombre().toLowerCase().contains(texto.toLowerCase())
                || String.valueOf(p.getId_producto()).equals(texto))
                .collect(Collectors.toList());

        vista.actualizarTabla(filtrados);
    }

    public void abrirDialogoNuevo() {
        DlgProducto dlg = new DlgProducto(null, true);
        dlg.setLocationRelativeTo(vista);
        dlg.setVisible(true);
        cargarTabla();
    }

    public void editarProducto() {
        int fila = vista.tblProductos.getSelectedRow();
        if (fila >= 0) {
            int id = (int) vista.tblProductos.getValueAt(fila, 0);
            Producto p = dao.buscarPorId(id);
            DlgProducto dlg = new DlgProducto(null, true);
            dlg.cargarDatosParaEditar(p);
            dlg.setLocationRelativeTo(vista);
            dlg.setVisible(true);
            cargarTabla();
        } else {
            JOptionPane.showMessageDialog(vista, "Selecciona un producto de la tabla.");
        }
    }

    public void eliminarProducto() {
        int fila = vista.tblProductos.getSelectedRow();
        if (fila >= 0) {
            int id = (int) vista.tblProductos.getValueAt(fila, 0);
            int conf = JOptionPane.showConfirmDialog(vista, "¿Eliminar este producto?");
            if (conf == JOptionPane.YES_OPTION) {
                if (dao.eliminar(id)) {
                    cargarTabla();
                }
            }
        }
    }
}
