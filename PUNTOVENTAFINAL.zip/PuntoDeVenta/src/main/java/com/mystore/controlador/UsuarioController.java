/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mystore.controlador;

import com.mystore.util.Conexion;
import com.mystore.vista.PnlUsuarios;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ericr
 */
public class UsuarioController {

   private PnlUsuarios vista;
    private int idUsuarioSeleccionado = 0;

    public UsuarioController(PnlUsuarios vista) {
        this.vista = vista;
        cargarTabla();
    }

    public void cargarTabla() {
        DefaultTableModel modelo = (DefaultTableModel) vista.tblUsuarios.getModel();
        modelo.setRowCount(0);

        String sql = "SELECT id_usuario, nombre, nombreUsuario FROM Usuario ORDER BY id_usuario ASC";

        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Object[] fila = {
                    rs.getInt("id_usuario"),
                    rs.getString("nombre"),
                    rs.getString("nombreUsuario")
                };
                modelo.addRow(fila);
            }
        } catch (Exception e) {
            System.err.println("Error al cargar usuarios desde el nodo remoto: " + e);
        }
    }

    public void guardarOActualizar() {
        String nombre = vista.txtNombre.getText().trim();
        String user = vista.txtUsuario.getText().trim();
        String pass = new String(vista.txtContrasena.getPassword()).trim();

        if (nombre.isEmpty() || user.isEmpty() || (idUsuarioSeleccionado == 0 && pass.isEmpty())) {
            JOptionPane.showMessageDialog(vista, "Todos los campos son obligatorios.");
            return;
        }

        if (idUsuarioSeleccionado == 0) {
            registrar(nombre, user, pass);
        } else {
            actualizar(nombre, user, pass);
        }
    }

    private void registrar(String nom, String user, String pass) {
        String sql = "INSERT INTO Usuario (nombre, nombreUsuario, contrasena) VALUES (?, ?, ?)";
        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nom);
            ps.setString(2, user);
            ps.setString(3, pass);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(vista, "Usuario registrado correctamente en el Nodo de Catálogo.");
            limpiar();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error al registrar en red: " + e.getMessage());
        }
    }

    private void actualizar(String nom, String user, String pass) {
        String sql = "UPDATE Usuario SET nombre=?, nombreUsuario=?, contrasena=? WHERE id_usuario=?";
        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nom);
            ps.setString(2, user);
            ps.setString(3, pass);
            ps.setInt(4, idUsuarioSeleccionado);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(vista, "Usuario modificado correctamente.");
            limpiar();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error al actualizar en red: " + e.getMessage());
        }
    }

    public void prepararEdicion() {
        int fila = vista.tblUsuarios.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(vista, "Selecciona un usuario de la tabla.");
            return;
        }

        idUsuarioSeleccionado = Integer.parseInt(vista.tblUsuarios.getValueAt(fila, 0).toString());
        String nombre = vista.tblUsuarios.getValueAt(fila, 1).toString();
        String usuario = vista.tblUsuarios.getValueAt(fila, 2).toString();

        vista.txtNombre.setText(nombre);
        vista.txtUsuario.setText(usuario);
        vista.txtContrasena.setText("");
        vista.btnGuardar.setText("Actualizar Usuario");
        vista.btnGuardar.setBackground(new java.awt.Color(52, 152, 219));
    }

    public void eliminarUsuario() {
        int fila = vista.tblUsuarios.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(vista, "Selecciona un usuario para eliminar.");
            return;
        }

        int id = Integer.parseInt(vista.tblUsuarios.getValueAt(fila, 0).toString());
        String nombre = vista.tblUsuarios.getValueAt(fila, 1).toString();

        if (JOptionPane.showConfirmDialog(vista, "¿Borrar permanentemente al usuario " + nombre + "?", "Confirmar Eliminación", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement("DELETE FROM Usuario WHERE id_usuario=?")) {
                ps.setInt(1, id);
                ps.executeUpdate();
                JOptionPane.showMessageDialog(vista, "Usuario eliminado del sistema distribuido.");
                limpiar();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(vista, "Error al eliminar: " + e.getMessage());
            }
        }
    }

    public void limpiar() {
        idUsuarioSeleccionado = 0;
        vista.txtNombre.setText("");
        vista.txtUsuario.setText("");
        vista.txtContrasena.setText("");
        vista.btnGuardar.setText("Registrar Usuario");
        vista.btnGuardar.setBackground(new java.awt.Color(46, 204, 113));
        cargarTabla();
    }
}