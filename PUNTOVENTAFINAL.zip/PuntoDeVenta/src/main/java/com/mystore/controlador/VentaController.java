/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mystore.controlador;

import com.mystore.util.Conexion;
import com.mystore.vista.PnlVentas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VentaController {

    private PnlVentas vista;

    public VentaController(PnlVentas vista) {
        this.vista = vista;
    }

    // 1. Busca el producto en el ComboBox, lee el Spinner y lo agrega al carrito
    public void agregarProducto() {
        if (vista.cmbProductos.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(vista, "No hay productos seleccionados.");
            return;
        }

        // Extraemos el ID del texto del ComboBox 
        String seleccion = vista.cmbProductos.getSelectedItem().toString();
        int idBusqueda = Integer.parseInt(seleccion.split("-")[0].trim());

        // Leemos la cantidad del Spinner
        int cantidadDeseada = (int) vista.spnCantidad.getValue();

        if (cantidadDeseada <= 0) {
            JOptionPane.showMessageDialog(vista, "La cantidad debe ser al menos 1.");
            return;
        }

        // Consultamos en Oracle por el ID 
        String sql = "SELECT id_producto, nombre, precio, stock FROM Producto WHERE id_producto = ?";

        try (Connection con = Conexion.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idBusqueda);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int id = rs.getInt("id_producto");
                    String nombre = rs.getString("nombre");
                    double precio = rs.getDouble("precio");
                    int stock = rs.getInt("stock");

                    if (stock < cantidadDeseada) {
                        JOptionPane.showMessageDialog(vista, "Stock insuficiente. Solo quedan " + stock + " piezas de " + nombre + ".");
                        return;
                    }

                    DefaultTableModel modelo = (DefaultTableModel) vista.tblCarrito.getModel();
                    boolean existeEnCarrito = false;

                    // Revisamos si ya está en el carrito para sumarle la nueva cantidad
                    for (int i = 0; i < modelo.getRowCount(); i++) {
                        if ((int) modelo.getValueAt(i, 0) == id) {
                            int cantidadActual = (int) modelo.getValueAt(i, 2);

                            // Validar que la suma no exceda el stock
                            if (cantidadActual + cantidadDeseada > stock) {
                                JOptionPane.showMessageDialog(vista, "Stock insuficiente. Ya tienes " + cantidadActual + " en el carrito. Solo hay " + stock + " disponibles.");
                                return;
                            }

                            int nuevaCantidad = cantidadActual + cantidadDeseada;
                            modelo.setValueAt(nuevaCantidad, i, 2);
                            modelo.setValueAt(nuevaCantidad * precio, i, 4); // Subtotal
                            existeEnCarrito = true;
                            break;
                        }
                    }

                    // Si no estaba en el carrito, lo agregamos como fila nueva
                    if (!existeEnCarrito) {
                        modelo.addRow(new Object[]{id, nombre, cantidadDeseada, precio, precio * cantidadDeseada});
                    }

                    calcularTotal();
                    vista.spnCantidad.setValue(1); // Regresamos el spinner a 1 por comodidad
                } else {
                    JOptionPane.showMessageDialog(vista, "Producto no encontrado en la base de datos.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(vista, "Error al agregar producto: " + e.getMessage());
        }
    }

    public void quitarProducto() {
        int filaSelec = vista.tblCarrito.getSelectedRow();
        if (filaSelec >= 0) {
            DefaultTableModel modelo = (DefaultTableModel) vista.tblCarrito.getModel();
            modelo.removeRow(filaSelec);
            calcularTotal();
        } else {
            JOptionPane.showMessageDialog(vista, "Por favor seleccione un producto del carrito para quitarlo.");
        }
    }

    private void calcularTotal() {
        DefaultTableModel modelo = (DefaultTableModel) vista.tblCarrito.getModel();
        double total = 0;
        for (int i = 0; i < modelo.getRowCount(); i++) {
            total += (double) modelo.getValueAt(i, 4);
        }
        vista.lblTotal.setText(String.format("$ %.2f", total));
    }

    public void finalizarVenta() {

        DefaultTableModel modelo = (DefaultTableModel) vista.tblCarrito.getModel();

        // Verifica que existan productos en el carrito
        if (modelo.getRowCount() == 0) {
            JOptionPane.showMessageDialog(vista,
                    "El carrito está vacío. Agrega productos primero.");
            return;
        }

        int confirmar = JOptionPane.showConfirmDialog(
                vista,
                "¿Deseas cobrar esta venta?",
                "Confirmar Cobro",
                JOptionPane.YES_NO_OPTION
        );

        if (confirmar != JOptionPane.YES_OPTION) {
            return;
        }

        try (Connection con = Conexion.getConnection()) {

            con.setAutoCommit(false);

            // Calcula el total general de la venta
            double totalVenta = 0;

            for (int i = 0; i < modelo.getRowCount(); i++) {
                totalVenta += (double) modelo.getValueAt(i, 4);
            }

            /*
         * Inserta la venta principal.
         * Se almacenan:
         * total de la venta
         * método de pago
         * estado de la venta
             */
            String sqlVenta = "INSERT INTO Venta "
                    + "(total, metodo_pago, estado) "
                    + "VALUES (?, ?, ?)";

            PreparedStatement psVenta = con.prepareStatement(sqlVenta);

            psVenta.setDouble(1, totalVenta);
            psVenta.setString(2, "Efectivo");
            psVenta.setString(3, "Completada");

            psVenta.executeUpdate();

            // Recupera el ID generado de la venta
            String sqlId = "SELECT MAX(id_venta) FROM Venta";

            PreparedStatement psId = con.prepareStatement(sqlId);

            ResultSet rsVenta = psId.executeQuery();

            int idVenta = 0;

            if (rsVenta.next()) {
                idVenta = rsVenta.getInt(1);
            }

            /*
         * Inserta el detalle de cada producto vendido
         * y actualiza el stock en inventario.
             */
            String sqlDetalle = "INSERT INTO Detalle_Venta "
                    + "(cantidad, precio_unitario, id_venta, id_producto) "
                    + "VALUES (?, ?, ?, ?)";

            String sqlStock = "UPDATE Producto "
                    + "SET stock = stock - ? "
                    + "WHERE id_producto = ?";

            PreparedStatement psDetalle = con.prepareStatement(sqlDetalle);
            PreparedStatement psStock = con.prepareStatement(sqlStock);

            for (int i = 0; i < modelo.getRowCount(); i++) {

                int idProd = (int) modelo.getValueAt(i, 0);
                int cantidad = (int) modelo.getValueAt(i, 2);
                double precio = (double) modelo.getValueAt(i, 3);

                // Guarda el detalle de venta
                psDetalle.setInt(1, cantidad);
                psDetalle.setDouble(2, precio);
                psDetalle.setInt(3, idVenta);
                psDetalle.setInt(4, idProd);

                psDetalle.executeUpdate();

                // Descuenta stock del producto
                psStock.setInt(1, cantidad);
                psStock.setInt(2, idProd);

                psStock.executeUpdate();
            }

            // Confirma toda la transacción
            con.commit();

            JOptionPane.showMessageDialog(
                    vista,
                    "¡Venta #" + idVenta + " registrada exitosamente!"
            );

            // Limpia el carrito después de finalizar la venta
            modelo.setRowCount(0);

            vista.lblTotal.setText("$ 0.00");

            // Recarga los productos disponibles
            vista.cargarProductosCombo();

        } catch (Exception e) {

            e.printStackTrace();

            JOptionPane.showMessageDialog(
                    vista,
                    "Error crítico al guardar la venta: " + e.getMessage()
            );
        }
    }
}
