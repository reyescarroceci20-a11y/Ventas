/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mystore.util;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * @author ericr clase para gestionar la conexión a la base de datos distribuida
 * Conecta exclusivamente al Nodo 2 local (Transacciones). Oracle se encargará
 * de enlazar con el Nodo 1 (Catálogo) vía DBLINK.
 */
public class Conexion {

    private static final String URL
            = "jdbc:oracle:thin:@//localhost:1521/xepdb1";

    private static final String USER = "nodo_catalogo";
    private static final String PASSWORD = "123";

    public static Connection getConnection() {

        try {

            System.out.println("--- ESTABLECIENDO CONEXIÓN A ORACLE ---");

            Class.forName("oracle.jdbc.OracleDriver");

            return DriverManager.getConnection(URL, USER, PASSWORD);

        } catch (Exception e) {

            System.err.println("Error crítico de conexión con Oracle: "
                    + e.getMessage());

            e.printStackTrace();

            return null;
        }
    }

}
