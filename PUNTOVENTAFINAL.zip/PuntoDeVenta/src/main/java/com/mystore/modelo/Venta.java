/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mystore.modelo;

import java.sql.Timestamp;

/**
 *
 * @author Ximena
 */
public class Venta {

    private int idVenta;
    private double total;
    private String metodoPago;
    private String estado;
    private Timestamp fecha;

    public Venta() {
    }

    public Venta(int idVenta, double total, String metodoPago, String estado, Timestamp fecha) {
        this.idVenta = idVenta;
        this.total = total;
        this.metodoPago = metodoPago;
        this.estado = estado;
        this.fecha = fecha;
    }

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Timestamp getFecha() {
        return fecha;
    }

    public void setFecha(Timestamp fecha) {
        this.fecha = fecha;
    }
}
